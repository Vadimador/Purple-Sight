void mut_arg(const u8 *_key, size_t *val) {
	*val = 5;
}
