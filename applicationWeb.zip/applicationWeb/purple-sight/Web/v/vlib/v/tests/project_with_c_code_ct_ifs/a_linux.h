char *version = "linux";
