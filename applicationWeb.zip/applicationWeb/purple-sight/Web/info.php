<?php
phpinfo();

 ?>
